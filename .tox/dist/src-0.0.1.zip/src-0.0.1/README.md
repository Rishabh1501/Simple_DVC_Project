# Simple_DVC_Project
### A project using DVC

It is a Wine Quality Prediction project made using DVC and Deployed on **Heroku** using **Github actions**

Here is the link to the Project, check it out 😉 : https://winequality-predict.herokuapp.com/
