

def test_generic():
    a = 10
    b = 10
    assert a == b
